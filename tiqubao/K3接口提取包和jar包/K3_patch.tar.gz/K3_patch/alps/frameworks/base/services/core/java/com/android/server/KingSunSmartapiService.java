package com.android.server;

import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.lang.*;
import java.util.HashMap;
import android.util.Log;
import android.view.InputEvent;
import android.view.InputFilter;
import android.view.KeyEvent;
import android.os.Handler;
import android.os.Message;
import android.os.RemoteException;
import android.app.kingsun.IKingSunSmartapiService;
import android.content.Context;
import android.provider.Settings;
import java.io.FileReader;
import java.io.Reader;
import java.io.BufferedReader;
import android.hardware.Sensor;  
import android.hardware.SensorEvent;  
import android.hardware.SensorEventListener;  
import android.hardware.SensorManager;
import android.util.Log;
import android.view.WindowManagerInternal;
import com.android.server.LocalServices;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import android.os.Binder;
/**
 *
 * Created by dengli
 */

public class KingSunSmartapiService extends IKingSunSmartapiService.Stub {

    private static final String TAG = "KingSunSmartapiService";
    private Context mContext = null;
    private float lux;
    private final SensorManager sm; 
    private final Sensor ligthSensor;
    
    
    public KingSunSmartapiService(Context context) {
        mContext=context;
        sm = (SensorManager)mContext.getSystemService(Context.SENSOR_SERVICE); 
        ligthSensor = sm.getDefaultSensor(Sensor.TYPE_LIGHT); 
		//add by dhy..
		mMainHandler = new Handler(context.getMainLooper()){
			@Override
			public void handleMessage(Message msg) {
				// TODO Auto-generated method stub
				super.handleMessage(msg);
			}
		};

		mKeyInputReciver = new InputFilter(mMainHandler.getLooper()){
			@Override
			public void onInputEvent(InputEvent event, int policyFlags) {
				// TODO Auto-generated method stub
				if (event instanceof KeyEvent) {
					KeyEvent keyEvent = (KeyEvent) event;
					int keyCode = keyEvent.getKeyCode();
					int action = keyEvent.getAction();
					Log.d("DHYCO",
							"my keycode = " + keyCode + ",,name=" + KeyEvent.keyCodeToString(keyCode) + ",,action=" + KeyEvent.actionToString(action));
					for (int i = 0; i < KEY_SIGNAL.length; i++) {
						if (KEY_SIGNAL[i] == keyCode) {
							if (action == KeyEvent.ACTION_UP)
								mKeySignalState[i] = 0;
							else if (action == KeyEvent.ACTION_DOWN)
								mKeySignalState[i] = 1;
							break;
						}
					}
				}
				super.onInputEvent(event, policyFlags);
			}
		};
		mWindowManagerService = LocalServices.getService(WindowManagerInternal.class);
		mWindowManagerService.setInputFilter(mKeyInputReciver);
		//end..
    }

    @Override
    public String getCpuSerial(){
       String cpuAddress = null;
        Object localOb;
        try {
            localOb = new FileReader("/sys/class/mmc_host/mmc0/mmc0:0001/cid");
            cpuAddress = new BufferedReader((Reader) localOb).readLine();
            Log.v("dengli", "cid: " + cpuAddress);
        } catch (Exception e1) {
            e1.printStackTrace();
        }
        return cpuAddress;
    }
    
    
    
    @Override
    public boolean adjustBrightness (int value){
        Log.d("dengli", "adjustBrightness  int value: " + value);
       if(value>=0&&value<=100){
            value=(int)(2.55f*value);
            Log.d("dengli", "adjustBrightness value: " + value);
            int mode = Settings.System.getInt(mContext.getContentResolver(),Settings.System.SCREEN_BRIGHTNESS_MODE,Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC);
            if (mode == Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC) {
                Settings.System.putInt(mContext.getContentResolver(),Settings.System.SCREEN_BRIGHTNESS_MODE,Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);
            }
             final long token = Binder.clearCallingIdentity();
             try {
                Settings.System.putInt(mContext.getContentResolver(),Settings.System.SCREEN_BRIGHTNESS, value);
             } finally {
                Binder.restoreCallingIdentity(token);
            }
        }
        int screenBrightness = Settings.System.getInt(mContext.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS,0);
        Log.d("dengli", "adjustBrightness screenBrightness: " + screenBrightness);
        if(value==screenBrightness){
            return true;
        }
        return false;
        
    }
    @Override
    public boolean setLcdBackLight(boolean enable){
        return true;
    }
    

    @Override    
    public float getLSensorValue(){
        sm.registerListener(new MySensorListener(), ligthSensor, SensorManager.SENSOR_DELAY_NORMAL);
        return lux;  
    }
    public class MySensorListener implements SensorEventListener {  
  
        public void onAccuracyChanged(Sensor sensor, int accuracy) {  
              
        }  
        public void onSensorChanged(SensorEvent event) {   
            float acc = event.accuracy;   
            lux = event.values[0]; 
            Log.d("dengli","ligthSensor ="+lux);
        }  
          
    }
	//add by dhy ..
	private static final String[] SYS_CLASS_FILES = { "/sys/class/or_info/or_info_data/or_status", "/sys/class/leds/led_red/brightness",
		"/sys/class/leds/led_blue/brightness", "/sys/class/leds/led_green/brightness", "/sys/class/leds/ph20/brightness","/sys/class/leds/led_whi/brightness","/sys/class/leds/led_ir/brightness"};
	// Key state..
	private static final int[] KEY_SIGNAL = { KeyEvent.KEYCODE_GPIO_KEY_LIMEN, KeyEvent.KEYCODE_GPIO_KEY_FANGCHAI, KeyEvent.KEYCODE_GPIO_KEY_REC };
	private int[] mKeySignalState = {-1,-1,-1};
	//final args...
	private final Handler mMainHandler;
	private final InputFilter mKeyInputReciver;
	private final WindowManagerInternal mWindowManagerService;

	private boolean sysClassOperation(String fileSysClass, boolean read, int[] ret) {
		boolean op_ret = false;
		try {
			if (read) {
				final byte[] buffer = new byte[8];
				final FileInputStream reader = new FileInputStream(fileSysClass);
				int len = reader.read(buffer);
				reader.close();
				ret[0] = Integer.valueOf(new String(buffer,0,len-1));
				op_ret = true;
			} else {
				final FileOutputStream writer = new FileOutputStream(fileSysClass);
				writer.write(Integer.toString(ret[0]).getBytes());
				writer.flush();
				writer.close();
				op_ret = true;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Log.e("DHYCO", "error:", e);
		}
		return op_ret;
	}

	@Override
	public int getServiceGpioState(int num){
		int[] value = { -1 };
		if (num >= SYS_CLASS_FILES.length)
			return mKeySignalState[num - SYS_CLASS_FILES.length];
		else
			sysClassOperation(SYS_CLASS_FILES[num], true, value);
		return value[0];
	}
	
	@Override
	public boolean setServiceGpioState(int num, int state){
		int[] value = { state };
		if (num >= SYS_CLASS_FILES.length)
			return false;
		return sysClassOperation(SYS_CLASS_FILES[num], false, value);
	}
	//end ..
}