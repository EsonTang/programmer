package android.app.kingsun;

/**
 * Created by dengli
 */
import android.annotation.SdkConstant;
import android.annotation.SystemApi;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;
import android.util.Log;

public class KingsunSmartAPI {
	//add by dhy .. gpio num,,
	/**
	 *继电器开门信号 GPIO。
	**/
	public static final int GPIO_HALL_NUM = 0;
	/**
	 *RGB 红灯 GPIO。
	**/
	public static final int GPIO_RED_LED_NUM = 1;
	/**
	 *RGB 蓝灯 GPIO。
	**/
	public static final int GPIO_BLUE_LED_NUM = 2;
	/**
	 *RGB 绿灯 GPIO。
	**/
	public static final int GPIO_GREEN_LED_NUM = 3;

	/**
	 *微波输入 GPIO。
	**/
	public static final int GPIO_WEIBO_NUM = 4;
	/**
	 *白光补光亮度 GPIO。
	**/
	public static final int GPIO_WHITE_LED_NUM = 5;
	/**
	 *红外补光亮度 GPIO。
	**/
	public static final int GPIO_INFRARED_LED_NUM = 6;
	
	/**
	 *离门信号 GPIO。
	**/
	public static final int GPIO_LIMEN_NUM = 7;
	/**
	 *防拆按键 GPIO。
	**/
	public static final int GPIO_FANGCHAI_NUM = 8;
	/**
	 *系统恢复按键 GPIO。
	**/
	public static final int GPIO_REC_NUM = 9;
	//end ...
    IKingSunSmartapiService mService;
    public KingsunSmartAPI(Context ctx,IKingSunSmartapiService service){
        mService=service;
    }
    
    public String getCpuSerial(){
       try{
            return mService.getCpuSerial();
        }catch(Exception e){
            Log.e("KingsunSmartAPI",e.toString());
            e.printStackTrace();
        }
        return null;
    }

    public boolean adjustBrightness (int value){
        try{
            return mService.adjustBrightness(value);
        }catch(Exception e){
            Log.e("KingsunSmartAPI",e.toString());
            e.printStackTrace();
        }
        return false;
        
    }

    public boolean setLcdBackLight(boolean enable){
        try{
            return mService.setLcdBackLight(enable);
        }catch(Exception e){
            Log.e("KingsunSmartAPI",e.toString());
            e.printStackTrace();
        }
        return false;
    }
    
    public float getLSensorValue(){
        try{
            return mService.getLSensorValue();
        }catch(Exception e){
            Log.e("KingsunSmartAPI",e.toString());
            e.printStackTrace();
        }
        return 0;
    }
	//add by dhy ..
	/**
	 * 
	 * @param num
	 *            gpio number,0 for hall_status,1 for led_red, 2 for led_blue,3
	 *            for led_green,4 for ph20..
	 * 
	 * @param state
	 *            the value will be setting.
	 * @return true if success,other false.
	 * 
	 */
    public boolean setGpioState(int num, int state){
        try{
            return mService.setServiceGpioState(num,state);
        }catch(Exception e){
            Log.e("KingsunSmartAPI",e.toString());
            e.printStackTrace();
        }
        return false;
    }
	
	/**
	 * 
	 * @param num
	 *            gpio number,0 for hall_status,1 for led_red, 2 for led_blue,3
	 *            for led_green,4 for ph20,5 for key 251,6 for 252,7for 253..
	 * @return the value read from gpio file.
	 * 
	 */
	public int getGpioState(int num) {
        try{
            return mService.getServiceGpioState(num);
        }catch(Exception e){
            Log.e("KingsunSmartAPI",e.toString());
            e.printStackTrace();
        }
        return -1;
    }
	//end ..
}