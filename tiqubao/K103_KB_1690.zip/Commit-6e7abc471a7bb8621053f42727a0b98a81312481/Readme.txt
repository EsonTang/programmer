========================================================================================
Time : 2018-09-12-15-42
Branch : K103_KB_1690
commit 6e7abc471a7bb8621053f42727a0b98a81312481
Author: zhengqf <zhengqf@szroco.com>
Date:   Tue May 16 11:09:07 2017 +0800

    解决设置本地漫游后国际漫游可以使用的问题
    
    branch K103_KB_1690
Mod:  frameworks/opt/telephony/src/java/com/android/internal/telephony/ServiceStateTracker.java
Mod:  packages/services/Telephony/src/com/android/phone/MobileNetworkSettings.java
